import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  usrname:string;
  pswd:string;
  msg:string;

  constructor(private logServ:LoginService, 
    private router:Router) {

      sessionStorage.clear(); // it will delete all the values from session
     }

  ngOnInit(): void {
  }

  CheckUserDetails()
  {
    if(this.usrname=="Admin" && this.pswd=="admin@123")
    {
      sessionStorage.setItem('userdetails', this.usrname);
      this.router.navigate(['/awelcome']);
    }
    else if(this.logServ.LoginCheck(this.usrname, this.pswd)==true)
    {
      sessionStorage.setItem('userdetails', this.usrname);
      this.router.navigate(['/ewelcome']);
    }
    else
      this.msg = "Please check username/password";
  }
}
