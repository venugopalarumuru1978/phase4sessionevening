import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-all-emps',
  templateUrl: './view-all-emps.component.html',
  styleUrls: ['./view-all-emps.component.css']
})
export class ViewAllEmpsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
