import { TestBed } from '@angular/core/testing';

import { TestsGuard } from './tests.guard';

describe('TestsGuard', () => {
  let guard: TestsGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(TestsGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
