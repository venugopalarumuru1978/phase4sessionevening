import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminwelcome',
  templateUrl: './adminwelcome.component.html',
  styleUrls: ['./adminwelcome.component.css']
})
export class AdminwelcomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
