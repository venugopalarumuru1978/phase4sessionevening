import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginService } from './login.service';

@Injectable({
  providedIn: 'root'
})

export class LoginGuard implements CanActivate {
  
  constructor(private router:Router, private logServ:LoginService)
  {}


  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    
    
      if(this.logServ.CheckLoginUser()==true)
      {
        //console.log("Hello" + this.router.url);
        if(this.router.url.length>0)
        {
            let urlmap = route.url[0].path;
            //console.log("Bye " + urlmap);
            if(urlmap=="awelcome" || urlmap=='vall'||urlmap=='ewelcome')
              return true;
        }
      }
      else
      {
         alert("First Login");
         this.router.navigate(['/login']);
         return false;
      }
  }
  
}
