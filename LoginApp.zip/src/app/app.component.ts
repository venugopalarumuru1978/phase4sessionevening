import { Component, DoCheck } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck {

  isNavbarVisiable:boolean=false;
  isNavbarVisiableEmp:boolean=false;

  title = 'LoginApp';

  constructor(private router:Router)
  {

  }
  ngDoCheck()
  {
      let currenturl = this.router.url; // it will give us, component link text which present in Address bar.
      console.log(currenturl);

      if(currenturl=="/login"  || currenturl=="/reg" || currenturl=="/")
      {
        this.isNavbarVisiable = false;
        this.isNavbarVisiableEmp = false;
      }
      else  if(currenturl=="/awelcome")
      {
        this.isNavbarVisiable = true;
        this.isNavbarVisiableEmp = false;
      }
      else  if(currenturl=="/ewelcome")
      {
        this.isNavbarVisiable = false;
        this.isNavbarVisiableEmp = true;
      }
      
        
  }
}
