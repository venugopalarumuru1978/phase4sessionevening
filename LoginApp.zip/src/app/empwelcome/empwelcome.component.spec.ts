import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpwelcomeComponent } from './empwelcome.component';

describe('EmpwelcomeComponent', () => {
  let component: EmpwelcomeComponent;
  let fixture: ComponentFixture<EmpwelcomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmpwelcomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpwelcomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
