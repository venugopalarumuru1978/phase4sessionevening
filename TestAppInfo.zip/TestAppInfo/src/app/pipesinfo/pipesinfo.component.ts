import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipesinfo',
  templateUrl: './pipesinfo.component.html',
  styleUrls: ['./pipesinfo.component.css']
})
export class PipesinfoComponent implements OnInit {
cname:string="Academy for Best Computer Education";
fees :number= 15000.00;
dt:Date=new Date();
pinfo:object = {"personName":"Kalyani", "age":34};

  constructor() { }

  ngOnInit(): void {
  }

}
