import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BindingsComponent } from './bindings/bindings.component';
import { DirectivesComponent } from './directives/directives.component';
import { PipesinfoComponent } from './pipesinfo/pipesinfo.component';
import { StudentComponent } from './student/student.component';
import { TestloginComponent } from './testlogin/testlogin.component';
import { TestregComponent } from './testreg/testreg.component';

const routes: Routes = [
  {path:"", component:StudentComponent},
  {path:"bind", component:BindingsComponent},
  {path:"dirt", component:DirectivesComponent},
  {path:"login", component:TestloginComponent},
  {path:"reg", component:TestregComponent},
  {path:"std", component:StudentComponent},
  {path:"pipes", component:PipesinfoComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
