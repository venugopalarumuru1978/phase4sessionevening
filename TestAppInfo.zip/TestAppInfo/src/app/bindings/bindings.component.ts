import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bindings',
  templateUrl: './bindings.component.html',
  styleUrls: ['./bindings.component.css']
})
export class BindingsComponent implements OnInit {
  personname:string = "Vennela";
  url:string = "http://www.facebook.com";

  constructor() { }

  ngOnInit(): void {
  }

  TestFun()
  {
    this.personname = "Venugopal Arumuru";
  }
}
