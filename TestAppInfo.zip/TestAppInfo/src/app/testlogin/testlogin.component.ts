import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testlogin',
  templateUrl: './testlogin.component.html',
  styleUrls: ['./testlogin.component.css']
})
export class TestloginComponent implements OnInit {

  username:string = "";
  password:string = "";
  msg:string="";

  constructor() { }

  ngOnInit(): void {
  }

  CheckLoginDetails()
  {
      if(this.username=="satyam" && this.password=="12345")
          this.msg = "Login Details are Correct";
      else
          this.msg = "Please check username/password";
  }
}
