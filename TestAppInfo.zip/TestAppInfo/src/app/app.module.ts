import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BindingsComponent } from './bindings/bindings.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TestloginComponent } from './testlogin/testlogin.component';
import { TestregComponent } from './testreg/testreg.component';
import { DirectivesComponent } from './directives/directives.component';
import { StudentComponent } from './student/student.component';
import { PipesinfoComponent } from './pipesinfo/pipesinfo.component';

@NgModule({
  declarations: [
    AppComponent,
    BindingsComponent,
    TestloginComponent,
    TestregComponent,
    DirectivesComponent,
    StudentComponent,
    PipesinfoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    FormsModule, NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
