import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {
  marks:number = 28;
  chk:boolean=false;
  cssclass:string = "";

  cities:string[] = ["Hyderabad", "Bangalore", "Mumbai", "Kolkatta", "Pune"];
  country:string="";
  
  constructor() {

    if(this.marks>=35)
    {
      this.chk = true;
      this.cssclass="cssgreen";
    }
    else
    {
      this.chk = false;
      this.cssclass="cssred";
    }

   }

  ngOnInit(): void {
  }

}
