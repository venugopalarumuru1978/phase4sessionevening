import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

   stdinfo:Student[] = [
    new Student(1001, "Pavan", "Java", 10000.00),
    new Student(1002, "Kumar", "Java", 10000.00),
    new Student(1003, "Mohan", "Java", 10000.00),
    new Student(1004, "Karan", "Java", 10000.00),
    new Student(1005, "Lavan", "Java", 10000.00)
  ];

  std :Student = new Student(0, "","",0.0);

  constructor() { }

  ngOnInit(): void {
  }

  AddNewStudent()
  {
    this.stdinfo.push(new Student(this.std.rollno, this.std.sname, this.std.course, this.std.fees));
    this.std.rollno = 0;
    this.std.sname = "";
    this.std.course = "";
    this.std.fees=0;
  }

  DeleteStudent(i:number)
  {
    this.stdinfo.splice(i,1);
  }
}
