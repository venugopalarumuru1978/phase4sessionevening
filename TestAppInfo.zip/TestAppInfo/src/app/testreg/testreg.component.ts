import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testreg',
  templateUrl: './testreg.component.html',
  styleUrls: ['./testreg.component.css']
})
export class TestregComponent implements OnInit {

  personname:string="";
  gender="Male";
  haveBike:boolean=false;
  location:string = "";
  
  msg:string="";

  constructor() { }

  ngOnInit(): void {
  }

  RegisterDetails()
  {
    this.msg = "Person Name : " + this.personname;
    this.msg +=  "<br />Gender : " + this.gender;
    if(this.haveBike==true)
      this.msg += "<br /> Yes, I have it";
    else
      this.msg += "<br />No, I am not Having it";
    this.msg += "<br />Location : "+ this.location;
  }
}
