import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';
import { AddnewempComponent } from './addnewemp/addnewemp.component';
import { ViewAllEmpInfoComponent } from './view-all-emp-info/view-all-emp-info.component';
import { ViewoneempComponent } from './viewoneemp/viewoneemp.component';
import { ModifyempComponent } from './modifyemp/modifyemp.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { FormsModule } from '@angular/forms';
import { Ng2OrderModule } from 'ng2-order-pipe';
@NgModule({
  declarations: [
    AppComponent,
    AddnewempComponent,
    ViewAllEmpInfoComponent,
    ViewoneempComponent,
    ModifyempComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule, 
    HttpClientModule, 
    ReactiveFormsModule, 
    NgxPaginationModule, 
    Ng2SearchPipeModule, 
    FormsModule, 
    Ng2OrderModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
