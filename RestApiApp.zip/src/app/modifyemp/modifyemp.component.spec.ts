import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyempComponent } from './modifyemp.component';

describe('ModifyempComponent', () => {
  let component: ModifyempComponent;
  let fixture: ComponentFixture<ModifyempComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModifyempComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyempComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
