import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
@Component({
  selector: 'app-modifyemp',
  templateUrl: './modifyemp.component.html',
  styleUrls: ['./modifyemp.component.css']
})
export class ModifyempComponent implements OnInit {
  emp:Employee = new Employee();
  idval:number;
  constructor(
    private builder:FormBuilder,
    private empServ:EmployeeService, 
    private aroute:ActivatedRoute, 
    private router:Router
  ) { }

  ngOnInit(): void {
    this.idval = this.aroute.snapshot.params['id'];
    this.getEmpInfo();
  }

  getEmpInfo()
{
  this.empServ.ViewEmpBasedOnEmpno(this.idval).subscribe(data=>{
    this.emp = data;
    console.log(data);
  });
}

UpdateEmployee()
{
  this.empServ.UpdateEmp(this.idval, this.empModForm.value).subscribe(data=>{
    console.log(data);
    this.router.navigate(['/viewall']);
  });
}

msg:string;
  empModForm = this.builder.group({
    id: this.builder.control('', [Validators.required]),
    firstName: this.builder.control('', [Validators.required]),
    lastName: this.builder.control('', [Validators.required]),
    emailId: this.builder.control('', [Validators.required]),
  });

}
