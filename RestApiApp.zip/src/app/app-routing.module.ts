import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddnewempComponent } from './addnewemp/addnewemp.component';
import { ModifyempComponent } from './modifyemp/modifyemp.component';
import { ViewAllEmpInfoComponent } from './view-all-emp-info/view-all-emp-info.component';
import { ViewoneempComponent } from './viewoneemp/viewoneemp.component';

const routes: Routes = [
  {path:"", component:ViewAllEmpInfoComponent},
  {path:"empreg", component:AddnewempComponent},
  {path:"viewall", component:ViewAllEmpInfoComponent}, 
  {path:"viewone/:id", component:ViewoneempComponent},
  {path:"modemp/:id", component:ModifyempComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
