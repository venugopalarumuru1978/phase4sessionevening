import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-viewoneemp',
  templateUrl: './viewoneemp.component.html',
  styleUrls: ['./viewoneemp.component.css']
})
export class ViewoneempComponent implements OnInit {
/*
ActivatedRoute :- this class is used to get value from url, QueryString.
*/
idval:number;
emp:Employee;
  constructor(private aroute:ActivatedRoute, 
    private empSer:EmployeeService, 
    private router:Router) { }

  ngOnInit(): void {
    this.idval = this.aroute.snapshot.params['id'];
    this.getEmpInfo();
  }

getEmpInfo()
{
  this.empSer.ViewEmpBasedOnEmpno(this.idval).subscribe(data=>{
    this.emp = data;
    console.log(data);
  });
}
}
