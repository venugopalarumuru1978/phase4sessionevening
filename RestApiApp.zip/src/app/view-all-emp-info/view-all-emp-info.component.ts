import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-view-all-emp-info',
  templateUrl: './view-all-emp-info.component.html',
  styleUrls: ['./view-all-emp-info.component.css']
})
export class ViewAllEmpInfoComponent implements OnInit {

  empInfo:Employee[];
  p:number;
  firstName:string;
  constructor(private empServ:EmployeeService, 
    private router:Router) { }

  ngOnInit(): void {
    this.viewAll();
  }

viewAll()
{
  this.empServ.ViewAllEmpInfo().subscribe(data=>{
    this.empInfo = data;
    console.log(data);
  });
}

delEmp(id:number)
{
  this.empServ.DeleteEmployee(id).subscribe(data=>{
    console.log(data);
    this.viewAll();
  });
}

viewEmpOne(id:number)
{
this.router.navigate(['/viewone', id]);
}
modEmp(id:number)
{
  this.router.navigate(['/modemp', id]);
}

SearchBasedOnFirstName()
{

  if(this.firstName=="")
  {
    this.viewAll();
  }
  else
  {
    console.log(this.firstName);
    this.empInfo = this.empInfo.filter(empObj=>{
      return empObj.firstName.toLocaleLowerCase().match(this.firstName);
    });
  }
}

key:string ="id";
reverse:boolean=false;
sorting(key:any)
{
  this.key = key;
  this.reverse =!this.reverse;
}
}
