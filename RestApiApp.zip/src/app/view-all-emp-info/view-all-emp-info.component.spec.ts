import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllEmpInfoComponent } from './view-all-emp-info.component';

describe('ViewAllEmpInfoComponent', () => {
  let component: ViewAllEmpInfoComponent;
  let fixture: ComponentFixture<ViewAllEmpInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAllEmpInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllEmpInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
