import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddStudentComponent } from './add-student/add-student.component';
import { ViewAllStudentsComponent } from './view-all-students/view-all-students.component';

const routes: Routes = [
  {path:"", component:ViewAllStudentsComponent},
  {path:"stdreg", component:AddStudentComponent},
  {path:"ViewAll", component:ViewAllStudentsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
