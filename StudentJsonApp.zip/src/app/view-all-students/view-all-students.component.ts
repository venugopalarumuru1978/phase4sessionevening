import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-view-all-students',
  templateUrl: './view-all-students.component.html',
  styleUrls: ['./view-all-students.component.css']
})
export class ViewAllStudentsComponent implements OnInit {

  stdinfo:Student[];

  constructor(
    private stdServ:StudentService
  ) { }

  ngOnInit(): void {
    this.viewstdAll();
  }

  viewstdAll()
  {
    this.stdServ.ViewAllStudents().subscribe(data=>{
      this.stdinfo = data;
    });
  }
}
