import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Student } from './student';
import {Observable} from 'rxjs'
@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(
    private httpClient:HttpClient
  ) { }

  private apiUrl = "http://localhost:3000/Student";

  CreateNewStudent(std:Student): Observable<Object>{
    return this.httpClient.post(`${this.apiUrl}`, std);
  }

  ViewAllStudents():Observable<Student[]>
  {
    return this.httpClient.get<Student[]>(`${this.apiUrl}`);
  }

}
