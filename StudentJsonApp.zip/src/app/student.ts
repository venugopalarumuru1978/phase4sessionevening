export class Student {
    id:number;
    sname:string;
    course:string;
    fees:number;
}
