import { Component, OnInit } from '@angular/core';
import {FormBuilder, Validators} from '@angular/forms';
import { StudentService } from '../student.service';
@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {

  constructor(
    private builder:FormBuilder, 
    private stdServe:StudentService
  ) { }

  ngOnInit(): void {
  }

  regStdForm = this.builder.group({
    "id": this.builder.control('', [Validators.required]),
    "sname": this.builder.control('', [Validators.required]),
    "course": this.builder.control('', [Validators.required]),
    "fees": this.builder.control('', [Validators.required])
  });

  addNewStudent()
  {
    this.stdServe.CreateNewStudent(this.regStdForm.value).subscribe(data=>{
      console.log(data);
      alert("Student Added...");
      this.regStdForm.reset();
    });
  }
}
