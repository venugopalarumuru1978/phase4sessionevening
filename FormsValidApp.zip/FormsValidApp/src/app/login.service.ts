import { Injectable } from '@angular/core';
import { Users } from './users';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  usersinfo:Users[] = [
    new Users("naresh", "12345"),
    new Users("ramesh", "12345"),
    new Users("mahesh", "12345")
  ];

  constructor() { }

  CheckUserDetails(usr:string, pwd:string):boolean
  {
    var chk = false;

    for(let i=0;i<this.usersinfo.length;i++)
    {
      if(this.usersinfo[i].username == usr && this.usersinfo[i].password==pwd)
        chk= true;
    }
    return chk;
  }

  CheckUser()
  {
    return sessionStorage.getItem("user")!=null;
  }
}
