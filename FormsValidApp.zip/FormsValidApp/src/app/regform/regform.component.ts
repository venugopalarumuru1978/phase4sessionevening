import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,  Validators } from '@angular/forms';
@Component({
  selector: 'app-regform',
  templateUrl: './regform.component.html',
  styleUrls: ['./regform.component.css']
})
export class RegformComponent implements OnInit {

  msg:string="";
  isFormSubmit:boolean=false;
  constructor() { }

  ngOnInit(): void {
  }

  regForm = new FormGroup({
    personname: new FormControl('', [Validators.required, Validators.minLength(5), Validators.pattern("^[a-zA-Z]*$")]),
    location: new FormControl('', [Validators.required]),
    phone: new FormControl('', [Validators.required, Validators.minLength(10)]),
    email: new FormControl('', [Validators.required])
  });

  RegisterPerson(frm:any)
  {
    if(frm.invalid)
    {
      this.isFormSubmit=true;
      alert("Invalid Form");
    }
    else
    {
      this.isFormSubmit=false;
      this.msg= this.regForm.controls.personname.value;
      this.msg += "<br />" + this.regForm.controls.location.value;
      this.msg += "<br />" + this.regForm.controls.phone.value;
      this.msg += "<br />" + this.regForm.controls.email.value;
    }
  }
}
