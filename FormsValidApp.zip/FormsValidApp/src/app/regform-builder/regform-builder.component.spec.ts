import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegformBuilderComponent } from './regform-builder.component';

describe('RegformBuilderComponent', () => {
  let component: RegformBuilderComponent;
  let fixture: ComponentFixture<RegformBuilderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegformBuilderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegformBuilderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
