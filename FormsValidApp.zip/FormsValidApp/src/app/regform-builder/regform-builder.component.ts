import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-regform-builder',
  templateUrl: './regform-builder.component.html',
  styleUrls: ['./regform-builder.component.css']
})
export class RegformBuilderComponent implements OnInit {
  /*
  as per angular, for Predefined classes and services, 
  objects has to be created as constructor arguments
  */
  constructor(
    private frmBuilder:FormBuilder
  ) { }
  isValidFormSubmitted = null;
  ngOnInit(): void {
  }
  msg:string="";
  registerForm = this.frmBuilder.group({
      personname: this.frmBuilder.control('', [Validators.required, Validators.pattern("^[a-zA-Z]*$")]),
      location: this.frmBuilder.control('', [Validators.required]),
      phone: this.frmBuilder.control('', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
      email: this.frmBuilder.control('', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")])
  });

  onFormSubmit() {
    
    if (this.registerForm.invalid) {
      this.isValidFormSubmitted = true;
       return;
    }
    else
    {
      this.isValidFormSubmitted = false;
      console.log(this.registerForm.value);
      this.msg = this.registerForm.value.personname;
      this.msg += "<br /> " + this.registerForm.value.location;
      this.msg += "<br /> " + this.registerForm.value.phone;
      this.msg += "<br /> " + this.registerForm.value.email;

    }
 }
}
