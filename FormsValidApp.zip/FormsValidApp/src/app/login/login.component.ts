import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:string="";
  password:string="";
  
  msg:string="";

  constructor(
    private logServ:LoginService, 
    private router:Router
  ) { 

    sessionStorage.clear();

  }

  ngOnInit(): void {
  }
CheckLoginDetails(frm:any)
{
  if(frm.invalid)
  {
    alert("Form is Invalid");
  }
  else
  {
    //if(this.username=="venugopal"  && this.password=="12345")
    if(this.logServ.CheckUserDetails(this.username, this.password)==true)
     {   
    //this.msg = this.username + " user details are correct";
        sessionStorage.setItem("user", this.username);
        this.router.navigate(['/welcome']);
     }
      else
      this.msg = "Invalid username/password";
  }
}
}
