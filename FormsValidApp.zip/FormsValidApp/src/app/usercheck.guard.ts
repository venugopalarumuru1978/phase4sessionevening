import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginService } from './login.service';

@Injectable({
  providedIn: 'root'
})
export class UsercheckGuard implements CanActivate {
  
  constructor(private router:Router, private logServ:LoginService)
  {}
  
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      if(this.logServ.CheckUser()==true)
      {
        //if(this.router.url.length>0)
        //{
          let urlmap = route.url[0].path;
          //alert(this.router.url.length + "....." + urlmap);
          if(urlmap=="welcome")
              return true;
        //}
      }
      else
      {
        alert("First Login.....");
        this.router.navigate(['/login']);
        return false;
      }
    
     
  }
  
}
