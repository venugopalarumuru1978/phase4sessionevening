import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegformBuilderComponent } from './regform-builder/regform-builder.component';
import { RegformComponent } from './regform/regform.component';
import { UsercheckGuard } from './usercheck.guard';
import { WelcomeComponent } from './welcome/welcome.component';

const routes: Routes = [
  {path:"", component:LoginComponent},
  {path:"login", component:LoginComponent},
  {path:"welcome", component:WelcomeComponent, canActivate:[UsercheckGuard]},
  {path:"reg2", component:RegformBuilderComponent},
  {path:"reg1", component:RegformComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
